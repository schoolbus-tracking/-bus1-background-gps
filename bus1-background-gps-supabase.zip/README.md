# Bus 1 — Native Android Background GPS + Supabase

هذا المشروع يحول باص 1 إلى تطبيق Android أصلي بدل الاعتماد على GPS داخل صفحة HTML.

## ما الذي يفعله؟

- تسجيل دخول Supabase بالبريد وكلمة المرور.
- حفظ جلسة الدخول على الهاتف.
- تشغيل GPS من خلال Android Foreground Service.
- استمرار إرسال الموقع عند الانتقال إلى تطبيق آخر أو إطفاء الشاشة، ما دام نظام Android يسمح للتطبيق بالعمل ولا يتم إيقافه قسراً.
- إرسال الموقع إلى جدول `buses2026`.
- قيمة الباص ثابتة: `bus1`.
- الأعمدة المستخدمة:
  - `bus`
  - `lat`
  - `lng`
  - `speed`
  - `timestamp`
- تحديث كل 3 ثوانٍ تقريباً.
- عند "إنهاء الرحلة": إيقاف GPS وحذف صف `bus1` من `buses2026`.
- تجديد Supabase access token تلقائياً عند انتهاء الجلسة.
- إشعار دائم أثناء التتبع.
- واجهة Android بسيطة مع خريطة Leaflet.

## قبل الرفع إلى GitHub

افتح:

`app/src/main/java/com/busdriver/bus1/Config.kt`

ثم ضع نفس **Supabase Publishable/anon key** المستخدم في مشروع HTML الحالي في:

`SUPABASE_PUBLISHABLE_KEY`

لا تستخدم `service_role` أو أي Secret key داخل التطبيق.

## صلاحيات Supabase

حساب السائق يجب أن يكون مستخدماً في Supabase Auth، ويجب أن تسمح RLS للمستخدم المصادق له بإدخال/تحديث وحذف صف `bus1` في `buses2026`.

الفكرة المطلوبة:

- INSERT: authenticated + bus = bus1
- UPDATE: authenticated + bus = bus1
- DELETE: authenticated + bus = bus1
- SELECT: authenticated + bus = bus1

## بناء APK

بعد رفع المشروع إلى GitHub:

Actions
→ Build Bus 1 APK
→ Run workflow

بعد انتهاء البناء:

Artifacts
→ bus1-background-gps-debug

حمّل ملف APK وثبته على هاتف السائق.

## ملاحظة Android

يجب السماح للموقع، ويفضل اختيار السماح بالموقع في الخلفية إذا ظهر الخيار في إصدار Android المستخدم. ويجب عدم إيقاف التطبيق يدوياً من إعدادات البطارية إذا كان الهاتف يطبق تقييداً شديداً على التطبيقات.

## مهم

هذا المشروع لا يحتاج Google Maps API؛ الخريطة تستخدم Leaflet وOpenStreetMap.
