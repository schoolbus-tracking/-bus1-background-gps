package com.busdriver.bus1

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class SupabaseSession(
    val accessToken: String,
    val refreshToken: String
)

class SupabaseClient(private val context: Context) {

    private val prefs = context.getSharedPreferences("bus1_auth", Context.MODE_PRIVATE)

    fun getAccessToken(): String? = prefs.getString("access_token", null)
    fun getRefreshToken(): String? = prefs.getString("refresh_token", null)

    private fun connection(
        urlString: String,
        method: String,
        bearer: String? = null
    ): HttpURLConnection {
        val c = URL(urlString).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("apikey", Config.SUPABASE_PUBLISHABLE_KEY)
        c.setRequestProperty("Accept", "application/json")
        if (!bearer.isNullOrBlank()) {
            c.setRequestProperty("Authorization", "Bearer $bearer")
        }
        if (method != "GET") {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
        }
        return c
    }

    private fun readBody(c: HttpURLConnection): String {
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return BufferedReader(stream.reader()).use { it.readText() }
    }

    fun login(email: String, password: String): Result<SupabaseSession> {
        return runCatching {
            val url = "${Config.SUPABASE_URL}/auth/v1/token?grant_type=password"
            val c = connection(url, "POST")
            val body = JSONObject()
                .put("email", email)
                .put("password", password)
                .toString()

            OutputStreamWriter(c.outputStream).use {
                it.write(body)
            }

            val response = readBody(c)
            if (c.responseCode !in 200..299) {
                error("تسجيل الدخول فشل: $response")
            }

            val json = JSONObject(response)
            val session = SupabaseSession(
                json.getString("access_token"),
                json.getString("refresh_token")
            )

            prefs.edit()
                .putString("access_token", session.accessToken)
                .putString("refresh_token", session.refreshToken)
                .putString("email", email)
                .apply()

            session
        }
    }

    fun refreshSession(): Result<SupabaseSession> {
        return runCatching {
            val refresh = getRefreshToken() ?: error("لا يوجد refresh token")
            val url = "${Config.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token"
            val c = connection(url, "POST")
            val body = JSONObject()
                .put("refresh_token", refresh)
                .toString()

            OutputStreamWriter(c.outputStream).use { it.write(body) }

            val response = readBody(c)
            if (c.responseCode !in 200..299) {
                error("تعذر تجديد جلسة Supabase: $response")
            }

            val json = JSONObject(response)
            val session = SupabaseSession(
                json.getString("access_token"),
                json.optString("refresh_token", refresh)
            )

            prefs.edit()
                .putString("access_token", session.accessToken)
                .putString("refresh_token", session.refreshToken)
                .apply()

            session
        }
    }

    fun hasSavedLogin(): Boolean =
        !getAccessToken().isNullOrBlank() && !getRefreshToken().isNullOrBlank()

    fun logout() {
        prefs.edit().clear().apply()
    }

    fun upsertLocation(lat: Double, lng: Double, speed: Double): Result<Unit> {
        return runCatching {
            var token = getAccessToken() ?: error("لا يوجد تسجيل دخول")

            var result = sendLocation(token, lat, lng, speed)
            if (result.first == 401 || result.first == 403) {
                token = refreshSession().getOrThrow().accessToken
                result = sendLocation(token, lat, lng, speed)
            }

            if (result.first !in 200..299) {
                error("فشل إرسال الموقع (${result.first}): ${result.second}")
            }
        }
    }

    private fun sendLocation(
        token: String,
        lat: Double,
        lng: Double,
        speed: Double
    ): Pair<Int, String> {
        val url =
            "${Config.SUPABASE_URL}/rest/v1/${Config.LOCATION_TABLE}" +
            "?on_conflict=bus"

        val c = connection(url, "POST", token)
        c.setRequestProperty("Prefer", "resolution=merge-duplicates,return=minimal")

        val timestamp = java.time.Instant.now().toString()
        val body = JSONObject()
            .put("bus", Config.BUS_ID)
            .put("lat", lat)
            .put("lng", lng)
            .put("speed", speed)
            .put("timestamp", timestamp)
            .toString()

        OutputStreamWriter(c.outputStream).use { it.write(body) }

        return c.responseCode to readBody(c)
    }

    fun clearLocation(): Result<Unit> {
        return runCatching {
            var token = getAccessToken() ?: error("لا يوجد تسجيل دخول")
            var result = deleteLocation(token)

            if (result.first == 401 || result.first == 403) {
                token = refreshSession().getOrThrow().accessToken
                result = deleteLocation(token)
            }

            if (result.first !in 200..299 && result.first != 404) {
                error("فشل مسح موقع الباص (${result.first}): ${result.second}")
            }
        }
    }

    private fun deleteLocation(token: String): Pair<Int, String> {
        val encodedBus = URLEncoder.encode(Config.BUS_ID, "UTF-8")
        val url =
            "${Config.SUPABASE_URL}/rest/v1/${Config.LOCATION_TABLE}" +
            "?bus=eq.$encodedBus"

        val c = connection(url, "DELETE", token)
        c.setRequestProperty("Prefer", "return=minimal")

        return c.responseCode to readBody(c)
    }
}
