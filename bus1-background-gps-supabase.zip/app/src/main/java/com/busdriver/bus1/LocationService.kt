package com.busdriver.bus1

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import java.util.Locale

class LocationService : android.app.Service() {

    companion object {
        const val ACTION_START = "com.busdriver.bus1.START"
        const val ACTION_STOP = "com.busdriver.bus1.STOP"
        private const val CHANNEL_ID = "bus1_location"
        private const val NOTIFICATION_ID = 1001
    }

    private lateinit var fused: FusedLocationProviderClient
    private lateinit var supabase: SupabaseClient
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation ?: return

            val lat = location.latitude
            val lng = location.longitude
            val speed = if (location.hasSpeed()) {
                location.speed.toDouble()
            } else {
                0.0
            }

            getSharedPreferences("bus1_runtime", MODE_PRIVATE)
                .edit()
                .putFloat("lat", lat.toFloat())
                .putFloat("lng", lng.toFloat())
                .putFloat("speed", speed.toFloat())
                .putLong("last_update", System.currentTimeMillis())
                .apply()

            serviceScope.launch {
                val resultSend = supabase.upsertLocation(lat, lng, speed)
                if (resultSend.isFailure) {
                    updateNotification("GPS يعمل — تعذر إرسال الموقع")
                } else {
                    val text = String.format(
                        Locale.US,
                        "GPS يعمل • %.6f, %.6f",
                        lat,
                        lng
                    )
                    updateNotification(text)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        supabase = SupabaseClient(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTracking()
            else -> startTracking()
        }
        return START_STICKY
    }

    private fun startTracking() {
        if (!hasLocationPermission()) {
            stopSelf()
            return
        }

        startForeground(NOTIFICATION_ID, buildNotification("جاري تشغيل تتبع باص 1"))

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            Config.GPS_INTERVAL_MS
        )
            .setMinUpdateIntervalMillis(Config.GPS_FASTEST_INTERVAL_MS)
            .setWaitForAccurateLocation(true)
            .setMaxUpdateDelayMillis(Config.GPS_INTERVAL_MS)
            .build()

        fused.requestLocationUpdates(
            request,
            callback,
            mainLooper
        )
    }

    private fun stopTracking() {
        fused.removeLocationUpdates(callback)

        serviceScope.launch {
            supabase.clearLocation()
            getSharedPreferences("bus1_runtime", MODE_PRIVATE)
                .edit()
                .clear()
                .apply()

            withContext(Dispatchers.Main) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarse = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fine || coarse
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.notification_channel_description)
                }
            )
        }
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("باص 1 — تتبع الموقع")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
