package com.busdriver.bus1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var loginBox: LinearLayout
    private lateinit var driverBox: LinearLayout
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var status: TextView
    private lateinit var coords: TextView
    private lateinit var startButton: Button
    private lateinit var finishButton: Button
    private lateinit var map: WebView

    private lateinit var supabase: SupabaseClient
    private val handler = Handler(Looper.getMainLooper())
    private val locationRequestCode = 2001

    private val uiUpdater = object : Runnable {
        override fun run() {
            updateRuntimeUi()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supabase = SupabaseClient(this)

        buildUi()
        requestPermissionsIfNeeded()

        if (supabase.hasSavedLogin()) {
            showDriver()
        } else {
            showLogin()
        }

        handler.post(uiUpdater)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }

        loginBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        email = EditText(this).apply {
            hint = "البريد الإلكتروني"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }

        password = EditText(this).apply {
            hint = "كلمة المرور"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val loginButton = Button(this).apply {
            text = "دخول"
            setOnClickListener { doLogin() }
        }

        loginBox.addView(title("تسجيل دخول باص 1"))
        loginBox.addView(email)
        loginBox.addView(password)
        loginBox.addView(loginButton)

        driverBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        driverBox.addView(title("لوحة السائق — باص 1"))

        status = TextView(this).apply {
            textSize = 17f
            setPadding(0, 20, 0, 20)
            text = "جاهز"
        }
        coords = TextView(this).apply {
            textSize = 16f
            text = "لا توجد قراءة حالية"
            setPadding(0, 0, 0, 12)
        }

        startButton = Button(this).apply {
            text = "بدء إرسال الموقع"
            setOnClickListener { startTracking() }
        }

        finishButton = Button(this).apply {
            text = "إنهاء الرحلة"
            setOnClickListener { stopTracking() }
        }

        driverBox.addView(status)
        driverBox.addView(coords)
        driverBox.addView(startButton)
        driverBox.addView(finishButton)

        map = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadDataWithBaseURL(
                "https://localhost/",
                mapHtml(),
                "text/html",
                "UTF-8",
                null
            )
        }

        driverBox.addView(
            map,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        root.addView(loginBox)
        root.addView(driverBox)

        setContentView(root)
    }

    private fun title(text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 25f
            setPadding(0, 10, 0, 20)
        }

    private fun showLogin() {
        loginBox.visibility = View.VISIBLE
        driverBox.visibility = View.GONE
    }

    private fun showDriver() {
        loginBox.visibility = View.GONE
        driverBox.visibility = View.VISIBLE
    }

    private fun doLogin() {
        val e = email.text.toString().trim()
        val p = password.text.toString()

        if (e.isBlank() || p.isBlank()) {
            Toast.makeText(this, "أدخل البريد وكلمة المرور", Toast.LENGTH_SHORT).show()
            return
        }

        status.text = "جاري تسجيل الدخول..."

        Thread {
            val result = supabase.login(e, p)
            runOnUiThread {
                if (result.isSuccess) {
                    showDriver()
                    status.text = "تم تسجيل الدخول"
                } else {
                    status.text = "فشل تسجيل الدخول"
                    Toast.makeText(
                        this,
                        result.exceptionOrNull()?.message ?: "خطأ غير معروف",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun startTracking() {
        if (!hasLocationPermission()) {
            requestPermissionsIfNeeded()
            return
        }

        val intent = Intent(this, LocationService::class.java)
            .setAction(LocationService.ACTION_START)

        ContextCompat.startForegroundService(this, intent)
        status.text = "جاري إرسال موقع باص 1..."
        startButton.isEnabled = false
    }

    private fun stopTracking() {
        val intent = Intent(this, LocationService::class.java)
            .setAction(LocationService.ACTION_STOP)

        startService(intent)
        status.text = "جاري إنهاء الرحلة ومسح الموقع..."
        startButton.isEnabled = true
    }

    private fun updateRuntimeUi() {
        val prefs = getSharedPreferences("bus1_runtime", MODE_PRIVATE)
        val lat = prefs.getFloat("lat", Float.NaN)
        val lng = prefs.getFloat("lng", Float.NaN)
        val last = prefs.getLong("last_update", 0L)

        if (!lat.isNaN() && !lng.isNaN()) {
            coords.text = "الموقع الحالي:\n$lat, $lng"
            map.evaluateJavascript(
                "window.setBusLocation($lat,$lng);",
                null
            )

            if (last > 0L) {
                val age = System.currentTimeMillis() - last
                if (age < 10000L) {
                    status.text = "🟢 التتبع يعمل"
                } else {
                    status.text = "🟡 بانتظار قراءة GPS"
                }
            }
        }
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissions.toTypedArray(),
                locationRequestCode
            )
        }
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarse = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fine || coarse
    }

    private fun mapHtml(): String = """
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet"
 href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
html,body,#map{height:100%;margin:0}
</style>
</head>
<body>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map=L.map('map').setView([31.9539,35.9106],12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
maxZoom:19,attribution:'© OpenStreetMap'
}).addTo(map);
let marker=null;
window.setBusLocation=function(lat,lng){
  if(!marker){
    marker=L.marker([lat,lng]).addTo(map);
    map.setView([lat,lng],16);
  }else{
    marker.setLatLng([lat,lng]);
  }
};
</script>
</body>
</html>
""".trimIndent()

    override fun onDestroy() {
        handler.removeCallbacks(uiUpdater)
        super.onDestroy()
    }
}
