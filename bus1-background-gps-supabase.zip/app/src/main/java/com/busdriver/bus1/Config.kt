package com.busdriver.bus1

object Config {
    // Supabase project URL from the existing Bus 1 project.
    const val SUPABASE_URL = "https://cfzqkgrzhepaxhsmqfdk.supabase.co"

    // Paste the same Supabase Publishable/anon key used by your current HTML project.
    // Do not paste a service_role/secret key here.
    const val SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE"

    const val BUS_ID = "bus1"
    const val LOCATION_TABLE = "buses2026"

    // Native background GPS interval.
    const val GPS_INTERVAL_MS = 3000L
    const val GPS_FASTEST_INTERVAL_MS = 1500L
}
